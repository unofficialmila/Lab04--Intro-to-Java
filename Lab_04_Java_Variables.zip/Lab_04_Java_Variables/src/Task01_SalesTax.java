public class Task01_SalesTax {

    public static void main(String[] args) {

        // Declaring Variables
        double purchaseTotal = 100;
        double salesTaxRate = 0.05;
        double salesTax;
        double total;

        // Calculate Sales Tax using Defined Variables
        salesTax = purchaseTotal * salesTaxRate;

        // Calculate Total Cost
        total = salesTax + purchaseTotal;

        // Output Price of Purchase and Sales Tax, and new Total
        System.out.println ("For a total purchase of: " + purchaseTotal);
        System.out.println ("With a sales tax rate of 5%, your sales tax will be: " + salesTax);
        System.out.println ("Giving you a total cost of: " + total);
    }
}

