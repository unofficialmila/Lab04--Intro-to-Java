public class Task02_YearlyMaintenanceCost {

    public static void main(String[] args) {

        // Declarations
        double winterCost = 150.0;
        double springCost = 200.0;
        double summerCost = 100.0;
        double fallCost = 250.0;
        double totalYearlyCost;

        // Calculating total yearly cost
        totalYearlyCost = winterCost + springCost + summerCost + fallCost;

        // Output seasonal costs and total
        System.out.println ("Winter Maintenance Cost: " + winterCost);
        System.out.println ("Spring Maintenance Cost: " + springCost);
        System.out.println ("Summer Maintenance Cost: " + summerCost);
        System.out.println ("Fall Maintenance Cost: " + fallCost);
        System.out.println ("Total Yearly Maintenance Cost: " + totalYearlyCost);
    }
}
