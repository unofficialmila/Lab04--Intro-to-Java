public class Task03_MonthlyCCBalance {

    public static void main(String[] args) {

        // Declaring Variables
        double INTEREST_RATE = 0.17;
        double CARD_BALANCE = 100;
        double firstMonthInterest;
        double secondMonthBalance;
        double secondMonthInterest;

        // First Month Interest
        firstMonthInterest = CARD_BALANCE * INTEREST_RATE;

        // Second Month Balance
        secondMonthBalance = CARD_BALANCE + firstMonthInterest;

        //Second Month Interest
        secondMonthInterest = secondMonthBalance * INTEREST_RATE;

        // Output Interest Due After 1 & 2 Months
        System.out.println ("The Interest due in 1 Month is: " + firstMonthInterest);
        System.out.println ("The interest due in 2 months is: " + secondMonthInterest);
    }
}
