public class Task04_EvenOdd {

    public static void main(String[] args) {

        // Declarations
        int numToExamine = 2;

        // Check if the number is even or odd using modulo function
        if (numToExamine % 2 == 0) {
            System.out.print ("The number is Even.");
        }
        else {
            System.out.print ("The number is Odd.");
        }
    }
}
